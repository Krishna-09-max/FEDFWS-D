# FitTrack – Fitness Tracker Application

A complete front-end fitness tracker built **only with HTML, CSS and JavaScript**.

## Modules
### 1. User Module
- Signup and Login using Local Storage
- Dashboard
- Workout logging
- Nutrition / calorie logging
- BMI calculator with status
- Fitness goals
- Profile
- Logout and account deletion

### 2. Admin Module
- Admin login
- User count and system statistics
- Search registered users
- View user details and activity counts
- Delete users and their stored records

## Demo Admin
- Email: `admin@fittrack.com`
- Password: `admin123`

## How to run in VS Code
1. Extract the ZIP.
2. Open the `FitTrack` folder in VS Code.
3. Open `index.html` in a browser.
4. For a better development workflow, install the **Live Server** extension in VS Code and choose **Open with Live Server** on `index.html`.
5. Create a normal user from Signup or use the admin credentials above.

## Local Storage
The application uses browser Local Storage keys for:
- users
- login session
- workouts
- foods
- goals

No backend, Python, database or framework is used.

## GitHub
```bash
git init
git add .
git commit -m "Create FitTrack fitness tracker"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/FitTrack.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

## Important academic note
The BMI calculation uses:
- Metric: BMI = weight(kg) / height(m)^2
- Imperial: BMI = weight(lb) × 703 / height(in)^2

BMI categories displayed:
- Underweight: below 18.5
- Healthy weight: 18.5–24.9
- Overweight: 25–29.9
- Obesity: 30+

BMI is a screening measure, not a medical diagnosis.
