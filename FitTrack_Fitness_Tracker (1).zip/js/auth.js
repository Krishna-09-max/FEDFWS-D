document.addEventListener('DOMContentLoaded',()=>{
  const admin={name:'Administrator',email:'admin@fittrack.com',password:'admin123',role:'admin'};
  if(!getUsers().some(u=>u.email===admin.email)){saveUsers([...getUsers(),admin])}
  const login=document.getElementById('loginForm');
  if(login)login.addEventListener('submit',e=>{e.preventDefault();const email=loginEmail.value.trim().toLowerCase(),password=loginPassword.value;const u=getUsers().find(x=>x.email===email&&x.password===password);const msg=document.getElementById('loginMsg');if(!u){msg.textContent='Invalid email or password.';msg.className='form-msg error';return}localStorage.setItem(SESSION_KEY,u.email);window.location.href=u.role==='admin'?'admin.html':'dashboard.html'});
  const signup=document.getElementById('signupForm');
  if(signup)signup.addEventListener('submit',e=>{e.preventDefault();const email=signupEmail.value.trim().toLowerCase();let users=getUsers();if(users.some(u=>u.email===email)){signupMsg.textContent='An account with this email already exists.';signupMsg.className='form-msg error';return}const u={name:signupName.value.trim(),email,password:signupPassword.value,age:Number(signupAge.value),goal:signupGoal.value,role:'user',createdAt:new Date().toISOString()};users.push(u);saveUsers(users);localStorage.setItem(SESSION_KEY,email);window.location.href='dashboard.html'});
});
