const USERS_KEY='fittrack_users', SESSION_KEY='fittrack_session';
function getUsers(){return JSON.parse(localStorage.getItem(USERS_KEY)||'[]')}
function saveUsers(users){localStorage.setItem(USERS_KEY,JSON.stringify(users))}
function currentUser(){const email=localStorage.getItem(SESSION_KEY);return getUsers().find(u=>u.email===email)}
function logout(){localStorage.removeItem(SESSION_KEY);window.location.href='login.html'}
function requireUser(){const u=currentUser();if(!u){window.location.href='login.html';return null}if(u.role==='admin'){window.location.href='admin.html';return null}return u}
function key(prefix,email){return 'fittrack_'+prefix+'_'+email}
function getData(prefix,email,fallback=[]){return JSON.parse(localStorage.getItem(key(prefix,email))||JSON.stringify(fallback))}
function setData(prefix,email,data){localStorage.setItem(key(prefix,email),JSON.stringify(data))}
function updateSidebar(){const u=currentUser();if(!u)return;document.querySelectorAll('#sideName').forEach(e=>e.textContent=u.name);document.querySelectorAll('#sideAvatar').forEach(e=>e.textContent=u.name.charAt(0).toUpperCase())}
document.addEventListener('DOMContentLoaded',()=>{updateSidebar()});
